require('dotenv').config();
const express = require('express');
const cookieParser = require('cookie-parser');
const rateLimit = require('express-rate-limit');

const app = express();
const authRoutes = require('./routes/auth');
const vaultRoutes = require('./routes/vault');

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 menit
  max: 100,                  // max 100 request per 15 menit
  message: { error: 'Terlalu banyak request, coba lagi nanti' }
});

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 menit
  max: 20,                   // max 20 request login/register per 15 menit
  message: { error: 'Terlalu banyak percobaan login, coba lagi nanti' }
});

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(limiter);

// CSRF protection
const { doubleCsrf } = require('csrf-csrf');
const { doubleCsrfProtection } = doubleCsrf({
  getSecret: () => process.env.JWT_SECRET,
  getSessionIdentifier: (req) => req.cookies['token'] || req.ip,
  getCsrfTokenFromRequest: (req) => req.body?._csrf || req.headers['x-csrf-token'],
  cookieName: 'csrf-token',
  cookieOptions: { sameSite: 'strict', secure: false },
  ignoredMethods: process.env.NODE_ENV === 'test' 
    ? ['GET', 'HEAD', 'OPTIONS', 'POST', 'PUT', 'DELETE', 'PATCH'] 
    : ['GET', 'HEAD', 'OPTIONS']
});
app.use(doubleCsrfProtection);

// Template engine
app.set('view engine', 'ejs');
app.set('views', './views');

// Static files
app.use(express.static('public'));
app.use('/auth', authLimiter, authRoutes);
app.use('/vault', vaultRoutes);

// Route sementara untuk test
app.get('/', (req, res) => {
  res.redirect('/auth/login');
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});

module.exports = app;